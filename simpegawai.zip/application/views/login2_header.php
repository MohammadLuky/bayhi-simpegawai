<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

	<link rel="icon" href="<?= base_url('assets/') ?>login2/bayhi.ico" type="image/x-icon">
	<link rel="stylesheet" href="<?= base_url('assets/login2/') ?>fonts/icomoon/style.css">

	<link rel="stylesheet" href="<?= base_url('assets/login2/') ?>css/owl.carousel.min.css">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/login2/') ?>css/bootstrap.min.css">

	<!-- Style -->
	<link rel="stylesheet" href="<?= base_url('assets/login2/') ?>css/style.css">

	<title><?= $title; ?></title>
</head>

<body>