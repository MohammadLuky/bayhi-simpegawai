<!DOCTYPE html>
<html lang="en">

<head>
    <title>Maintenance</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <!-- <link rel="icon" type="image/png" href="<?= base_url('assets/maintenance/'); ?>images/icons/favicon.ico" /> -->
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/') ?>bayhi.ico">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/maintenance/'); ?>vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/maintenance/'); ?>vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/maintenance/'); ?>vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/maintenance/'); ?>css/util.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/maintenance/'); ?>css/main.css">
    <!--===============================================================================================-->
</head>

<body>


    <div class="bg-img1 size1 flex-w flex-c-m p-t-55 p-b-55 p-l-15 p-r-15" style="background-image: url('<?= base_url('assets/'); ?>manage/img/bayhi.jpg');">
        <!-- <div class="bg-img1 size1 flex-w flex-c-m p-t-55 p-b-55 p-l-15 p-r-15" style="background-image: url('<?= base_url('assets/maintenance/'); ?>images/bg01.jpg');"> -->
        <div class="wsize1 bor1 bg1 p-t-90 p-b-45 p-l-15 p-r-15 respon1">
            <div class="wrappic1">
                <img src="<?= base_url('assets/') ?>bayhi.ico" alt="LOGO" width="80px">
                <!-- <img src="<?= base_url('assets/maintenance/'); ?>images/icons/logo.png" alt="LOGO"> -->
            </div>

            <p class="txt-center m1-txt1 p-t-33 p-b-5">
                Sistem Manajemen Rekrutmen Pegawai PP. Bayt Al-hikmah dalam proses perbaikan.
            </p>
            <p class="txt-center m1-txt1 p-t-5 p-b-30">
                Mohon bersabar dan selalu cek laman ini. Terimakasih.
            </p>

            <!-- <div class="wsize2 flex-w flex-c hsize1 cd100">
                <div class="flex-col-c-m size2 how-countdown">
                    <span class="l1-txt1 p-b-9 days">35</span>
                    <span class="s1-txt1">Days</span>
                </div>

                <div class="flex-col-c-m size2 how-countdown">
                    <span class="l1-txt1 p-b-9 hours">17</span>
                    <span class="s1-txt1">Hours</span>
                </div>

                <div class="flex-col-c-m size2 how-countdown">
                    <span class="l1-txt1 p-b-9 minutes">50</span>
                    <span class="s1-txt1">Minutes</span>
                </div>

                <div class="flex-col-c-m size2 how-countdown">
                    <span class="l1-txt1 p-b-9 seconds">39</span>
                    <span class="s1-txt1">Seconds</span>
                </div>
            </div> -->

            <a href="" class="flex-c-m s1-txt3 size3 how-btn trans-04 where1">Kembali</a>

            <!-- <form class="flex-w flex-c-m contact100-form validate-form p-t-55">
                <div class="wrap-input100 validate-input where1" data-validate="Email is required: ex@abc.xyz">
                    <input class="s1-txt2 placeholder0 input100" type="text" name="email" placeholder="Your Email">
                    <span class="focus-input100"></span>
                </div>


                <button class="flex-c-m s1-txt3 size3 how-btn trans-04 where1">
                    Get Notified
                </button>

            </form> -->

            <!-- <p class="s1-txt4 txt-center p-t-10">
                I promise to <span class="bor2">never</span> spam
            </p> -->

        </div>
    </div>





    <!--===============================================================================================-->
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/bootstrap/js/popper.js"></script>
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/countdowntime/moment.min.js"></script>
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/countdowntime/moment-timezone.min.js"></script>
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/countdowntime/moment-timezone-with-data.min.js"></script>
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/countdowntime/countdowntime.js"></script>
    <script>
        $('.cd100').countdown100({
            /*Set Endtime here*/
            /*Endtime must be > current time*/
            endtimeYear: 0,
            endtimeMonth: 0,
            endtimeDate: 35,
            endtimeHours: 18,
            endtimeMinutes: 0,
            endtimeSeconds: 0,
            timeZone: ""
            // ex:  timeZone: "America/New_York"
            //go to " http://momentjs.com/timezone/ " to get timezone
        });
    </script>
    <!--===============================================================================================-->
    <script src="<?= base_url('assets/maintenance/'); ?>vendor/tilt/tilt.jquery.min.js"></script>
    <script>
        $('.js-tilt').tilt({
            scale: 1.1
        })
    </script>
    <!--===============================================================================================-->
    <script src="<?= base_url('assets/maintenance/'); ?>js/main.js"></script>

</body>

</html>