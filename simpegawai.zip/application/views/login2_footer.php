<script src="<?= base_url('assets/login2/') ?>js/jquery-3.3.1.min.js"></script>
<script src="<?= base_url('assets/login2/') ?>js/popper.min.js"></script>
<script src="<?= base_url('assets/login2/') ?>js/bootstrap.min.js"></script>
<script src="<?= base_url('assets/login2/') ?>js/main.js"></script>

</body>

</html>