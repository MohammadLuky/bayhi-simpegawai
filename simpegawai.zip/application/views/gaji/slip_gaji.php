<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .slip-gaji-card {
            width: 300px;
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            position: relative;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-family: Arial, sans-serif;
        }

        .circle-decorator {
            width: 80px;
            height: 40px;
            background: teal;
            border-radius: 0 0 80px 80px;
            position: absolute;
            top: -20px;
            right: -20px;
        }

        .card-content {
            z-index: 1;
        }

        .card-content h4 {
            margin: 0 0 10px;
            color: teal;
        }

        .card-content p {
            margin: 5px 0;
            font-size: 14px;
            color: #333;
        }

        .card-content p strong {
            font-weight: bold;
        }
    </style>
</head>

<body>

    <div class="slip-gaji-card">
        <div class="circle-decorator"></div>
        <div class="card-content">
            <h4>Slip Gaji</h4>
            <p><strong>Nama:</strong> John Doe</p>
            <p><strong>Jabatan:</strong> Software Engineer</p>
            <p><strong>Gaji Pokok:</strong> Rp 10.000.000</p>
            <p><strong>Tunjangan:</strong> Rp 2.000.000</p>
            <p><strong>Total Gaji:</strong> Rp 12.000.000</p>
        </div>
    </div>


</body>

</html>